package gestclub.ihm;
public class Main1 {

	public static void main(String[] args) {
		// Cr�ation et affichage d'une fenetre FrameSaisieMembre
		
		FrameSaisieMembre fenetre = new FrameSaisieMembre();
		
		fenetre.setVisible( true );
	}

}
