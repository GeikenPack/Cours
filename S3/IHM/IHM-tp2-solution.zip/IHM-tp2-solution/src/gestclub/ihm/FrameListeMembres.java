package gestclub.ihm;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import gestclub.donnees.Membre;

@SuppressWarnings("serial")
public class FrameListeMembres extends JFrame implements ActionListener {
	
	private DefaultListModel<Membre> listModel = new DefaultListModel<Membre>();
	private JList<Membre>            liste     = new JList<Membre>(listModel);

	private JButton butModifier = new JButton("Modifier");
	private JButton butAjouter  = new JButton("Ajouter");
	
	public FrameListeMembres(ArrayList<Membre> listeMembres) {
		this();
		setListeMembre(listeMembres);
		this.pack();
	}
	public FrameListeMembres() {
		
		super("Liste de membres");
		
		this.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		
		JPanel panBouton = new JPanel();

		this.setLayout( new BorderLayout() );
		this.add( new JScrollPane(liste),    BorderLayout.CENTER );
		this.add(panBouton, BorderLayout.SOUTH  );
		
		panBouton.setLayout( new FlowLayout() );
		panBouton.add( butModifier );
		panBouton.add( butAjouter );

		liste.setPreferredSize(new Dimension(320,200));
		liste.setBackground( Color.CYAN );
		
		butModifier.addActionListener(this);
		butAjouter.addActionListener(this);
		
		this.pack();
	}
	public void setListeMembre( ArrayList<Membre> listeMembres ) {
		this.listModel.clear();
		for ( Membre m : listeMembres ) {
			this.listModel.addElement(m);
		}
	}
	@Override
	public void actionPerformed(ActionEvent ae) {

		if ( ae.getSource() == this.butAjouter ) {
			Membre nouveauMembre = new Membre("Nouveau", "membre", "inconnue", true);
			this.listModel.addElement(nouveauMembre);
		} else if ( ae.getSource() == this.butModifier ) {
			if (this.liste.getSelectedIndex()>=0) {
				Membre membre = this.listModel.get(  this.liste.getSelectedIndex()  );
				System.out.println("OK : nous allons modifier " + membre.prenom + " " + membre.nom  );				
			} else {
				System.out.println("Vous devez s�lectionner un membre pour pouvoir le modifier");
			}
		}
		
	}

}
