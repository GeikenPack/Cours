package gestclub.ihm;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import gestclub.donnees.Membre;
import gestclub.donnees.Sports;

public class Main3 {

	public static void main(String[] args) {
		
		Set<Sports> sportsSet1 = new HashSet<Sports>();
		sportsSet1.add(Sports.Natation);
		sportsSet1.add(Sports.Randonnee);
		sportsSet1.add(Sports.Petanque);

		Set<Sports> sportsSet2 = new HashSet<Sports>();
		sportsSet2.add(Sports.Basket);
		
		ArrayList<Membre> listeMembre = new ArrayList<>();
		
		listeMembre.add( new Membre("Bond",   "Jean",   "26 route du chemin\n31000 Toulouse", true, sportsSet1) );
		listeMembre.add( new Membre("Dupond", "Pierre", "26 route du chemin\n31000 Toulouse", true, sportsSet2) );
		listeMembre.add( new Membre("Dupont", "Marie",  "26 route du chemin\n31000 Toulouse", false ) );		
		
		FrameListeMembres fenetre = new FrameListeMembres( listeMembre );

//		FrameListeMembres fenetre = new FrameListeMembres(  );
		
		fenetre.setVisible( true );
	}

}
