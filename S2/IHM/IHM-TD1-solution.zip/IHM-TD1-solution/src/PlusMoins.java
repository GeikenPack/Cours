import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Font;

@SuppressWarnings("serial")
public class PlusMoins extends JFrame {

	public PlusMoins() {
		super();
		
		// Cr�ation des composants
		JTextField zoneTexte = new JTextField();
		JPanel     panelBas  = new JPanel();
		JButton    butPlus   = new JButton("+");
		JButton    butMoins  = new JButton("-");
		JButton    butRaz    = new JButton("RAZ");
		Font       police    = new Font( "Arial", Font.BOLD, 18 );

		// Param�trage des composants
		this.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		this.setTitle("Plus ou moins");
		
		butPlus.setBackground(  Color.GREEN );
		butMoins.setBackground( Color.RED   );
		butRaz.setBackground(   Color.BLUE  );

		zoneTexte.setText("10");
		zoneTexte.setEditable(false);
		zoneTexte.setHorizontalAlignment( JTextField.CENTER );
		zoneTexte.setBackground( Color.WHITE );

		zoneTexte.setFont(police);
		butPlus.setFont(police);
		butMoins.setFont(police);
		butRaz.setFont(police);
		
		// Assemblage des composants
		getContentPane().setLayout( new BorderLayout() );
		getContentPane().add( zoneTexte, BorderLayout.CENTER );
		getContentPane().add( panelBas,  BorderLayout.SOUTH );
		
		panelBas.setLayout( new GridLayout(1, 3) );
		panelBas.add(butPlus);
		panelBas.add(butRaz);
		panelBas.add(butMoins);
		
		// Mise en page adapt�e aux contraintes
		this.setSize(new Dimension(280, 120));
		
	}
	
}
