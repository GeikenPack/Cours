import javax.swing.JFrame;

public class Main {

	public static void main(String[] args) {

		JFrame plusMoins = new PlusMoins();
		plusMoins.setVisible( true );
		
		System.out.println("Fin du main() mais l'application graphique est toujours active");

	}

}
