import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Font;

@SuppressWarnings("serial")
public class PlusMoins extends JFrame implements ActionListener, KeyListener {

	private JTextField zoneTexte = new JTextField();
	private JButton    butPlus   = new JButton("+");
	private JButton    butMoins  = new JButton("-");
	private JButton    butRaz    = new JButton("RAZ");

	static final int    VALEUR_INIT    = 10;
	static final String ACTION_PLUS    = "Plus";
	static final String ACTION_MOINS   = "Moins";
	static final String ACTION_RAZ     = "Raz";
	static final String ACTION_QUITTER = "Quitter";
	static final String ACTION_AIDE    = "Aide";


	public PlusMoins() {
		super();

		// ===================================================================
		// Cr�ation des composants
		JPanel     panelBas  = new JPanel();
		Font       police    = new Font( "Arial", Font.BOLD, 18 );

		// ===================================================================
		// Param�trage des composants
		this.setDefaultCloseOperation( JFrame.DO_NOTHING_ON_CLOSE );
		this.setTitle("Plus ou moins Complet");

		this.butPlus.setBackground(  Color.GREEN );
		this.butMoins.setBackground( Color.RED   );
		this.butRaz.setBackground(   Color.BLUE  );

		this.zoneTexte.setText(""+VALEUR_INIT);
		this.zoneTexte.setEditable(false);
		this.zoneTexte.setHorizontalAlignment( JTextField.CENTER );
		this.zoneTexte.setBackground( Color.WHITE );

		this.zoneTexte.setFont(police);
		this.butPlus.setFont(police);
		this.butMoins.setFont(police);
		this.butRaz.setFont(police);

		// ===================================================================
		// Assemblage des composants
		getContentPane().setLayout( new BorderLayout() );
		getContentPane().add( this.zoneTexte, BorderLayout.CENTER );
		getContentPane().add( panelBas,  BorderLayout.SOUTH );

		panelBas.setLayout( new GridLayout(1, 3) );
		panelBas.add(this.butPlus);
		panelBas.add(this.butRaz);
		panelBas.add(this.butMoins);

		// ===================================================================
		// Menus
		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		JMenuBar menuBar = new JMenuBar();
		this.setJMenuBar(menuBar);

		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		JMenu menu = new JMenu("Actions");
		menuBar.add(menu);
		
		JMenuItem menuItem = new JMenuItem("Plus");
		menuItem.setActionCommand(ACTION_PLUS);
		menuItem.addActionListener( this );
		menu.add(menuItem);

		menuItem = new JMenuItem("Moins");
		menuItem.setActionCommand(ACTION_MOINS);
		menuItem.addActionListener( this );
		menu.add(menuItem);

		menu.addSeparator();

		menuItem = new JMenuItem("RAZ");
		menuItem.setActionCommand(ACTION_RAZ);
		menuItem.addActionListener( this );
		menu.add(menuItem);
		
		menu.addSeparator();

		menuItem = new JMenuItem("Quitter");
		menuItem.setActionCommand(ACTION_QUITTER);
		menuItem.addActionListener( this );
		menu.add(menuItem);
		
		// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
		menu = new JMenu("?");
		menuBar.add(menu);

		menuItem = new JMenuItem("Aide");
		menuItem.setActionCommand(ACTION_AIDE);
		menuItem.addActionListener(this);
		menu.add(menuItem);
		
		// ===================================================================
		// Gestion des actions
		this.butPlus.setActionCommand( ACTION_PLUS);
		this.butMoins.setActionCommand(ACTION_MOINS);
		this.butRaz.setActionCommand(  ACTION_RAZ);
		this.butPlus.addActionListener(  this );
		this.butMoins.addActionListener( this );
		this.butRaz.addActionListener(   this );

		this.addWindowListener( new WindowAdapter() {
			public void windowClosing(WindowEvent arg0) {
				
				quitter();  // PlusMoins.this.quitter();
			}
		});
		
		this.setFocusable(true);
		this.addKeyListener( this );
		this.zoneTexte.addKeyListener( this );
		this.butPlus.addKeyListener( this );
		this.butMoins.addKeyListener( this );
		this.butRaz.addKeyListener( this );

		// ===================================================================
		// Mise en page
		this.setSize(new Dimension(280, 120));

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		int valeur;
		try {
			valeur = Integer.parseInt( this.zoneTexte.getText() );
		} catch (NumberFormatException nfe) {
			valeur = VALEUR_INIT;
		}
		switch ( e.getActionCommand() ) {
		case ACTION_PLUS:
			valeur ++;
			break;
		case ACTION_MOINS:
			valeur --;
			break;
		case ACTION_RAZ:
			valeur = VALEUR_INIT;
			break;
		case ACTION_AIDE:
			JOptionPane.showMessageDialog(this, "<html><h1>JPlusMoins 3.0</h1><br/><br/>Fabrice PELLEAU - 2021</html>", "JPlusMoins 3.0" , JOptionPane.INFORMATION_MESSAGE);
			break;
		case ACTION_QUITTER:
			quitter();
			break;
		default:
			System.out.println("Action inconnue ???");
		}
		this.zoneTexte.setText(""+valeur);
	}


	public void quitter_versionsimple() {

		int reponse = JOptionPane.showConfirmDialog(this, "Voulez-vous quitter ?"); 
		if ( reponse == JOptionPane.YES_OPTION ) {
			// this.dispose(); // d�truire la fen�tre proprement (l'application fermera si c'�tait la derni�re fen�tre)
			System.exit(0);    // quitter imm�diatement l'application (ind�pendamment de tout autre processus en cours)
		} else if(reponse == JOptionPane.NO_OPTION) {
			JOptionPane.showMessageDialog(this, "OK on reste encore un peu..." ); 
		} 

	}

	public void quitter() {
		int reponse = JOptionPane.showConfirmDialog(this, "Si vous quittez maintenant,\ntoutes vos modifications seront perdues.\nVoulez-vous r�ellement quitter l'application ?", "Quitter l'application ?",
                									JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE ); 
		if ( reponse == JOptionPane.YES_OPTION ) {
			System.exit(0);
		} else if(reponse == JOptionPane.NO_OPTION) {
			JOptionPane.showMessageDialog(this, "OK on reste encore un peu..." ); 
		} 

	}

	@Override
	public void keyPressed(KeyEvent ke) {
	}

	@Override
	public void keyReleased(KeyEvent ke) {
	}

	@Override
	public void keyTyped(KeyEvent ke) {
		if (ke.getKeyChar()=='+') {
			this.butPlus.doClick();
		} else if (ke.getKeyChar()=='-') {
			this.butMoins.doClick();
		}
	}

}
