package gestclub.ihm;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.BevelBorder;

import gestclub.donnees.Membre;
import gestclub.donnees.Sports;

@SuppressWarnings("serial")
public class FrameSaisieMembre extends JFrame {
	
	private JRadioButton radioHomme         = new JRadioButton("Homme");
	private JRadioButton radioFemme         = new JRadioButton("Femme");
	private JTextField   txtNom             = new JTextField(10);
	private JTextField   txtPrenom          = new JTextField(10);
	private JTextArea    txtAdresse         = new JTextArea(5, 10);
	private JCheckBox[]  casesACocherSports = new JCheckBox[Sports.NOMBRE];
	private JButton      butOK              = new JButton("OK");
	private JButton      butAnnuler         = new JButton("Annuler");

    public FrameSaisieMembre(Membre membre) {
    	this();
    	this.setMembre( membre );
    }
    public FrameSaisieMembre() {
        super("Saisie membre");
        
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel contentPane = new JPanel();
        
        JPanel grandCentre = new JPanel();
        JPanel grandEst    = new JPanel();
        JPanel grandSud    = new JPanel();
        
        contentPane.setLayout(new BorderLayout());
        contentPane.add(grandCentre, BorderLayout.CENTER);
        contentPane.add(grandEst,    BorderLayout.EAST);
        contentPane.add(grandSud,    BorderLayout.SOUTH);

        this.setContentPane(contentPane);

        JPanel petitNord   = new JPanel();
        JPanel petitCentre = new JPanel();
        JPanel petitSud    = new JPanel();
        
        grandCentre.setLayout(new BorderLayout());
        grandCentre.add(petitNord,   BorderLayout.NORTH);
        grandCentre.add(petitCentre, BorderLayout.CENTER);
        grandCentre.add(petitSud,    BorderLayout.SOUTH);
        
        grandEst.setLayout(   new GridLayout(9,1));
        grandSud.setLayout(   new FlowLayout());
        petitNord.setLayout(  new GridLayout(4,1));
        petitCentre.setLayout(new BorderLayout());
        petitSud.setLayout(   new FlowLayout());

        contentPane.setBorder( BorderFactory.createEmptyBorder(5, 5, 5, 5) );
        grandCentre.setBorder(
        		BorderFactory.createCompoundBorder(
        				BorderFactory.createBevelBorder( BevelBorder.LOWERED  ),
        				BorderFactory.createEmptyBorder(5, 5, 5, 5) )
        		 );
        grandEst.setBorder(    BorderFactory.createTitledBorder("Sports") );

        txtAdresse.setBorder( txtNom.getBorder() );

        
        petitNord.add(new JLabel("Nom"));
        petitNord.add(txtNom);
        petitNord.add(new JLabel("Pr�nom"));
        petitNord.add(txtPrenom);
        
        petitCentre.add(new JLabel("Adresse"),BorderLayout.NORTH);
        petitCentre.add(txtAdresse,BorderLayout.CENTER);
        
        petitSud.add(new JLabel("Sexe"));
        petitSud.add(radioHomme);
        petitSud.add(radioFemme);

        ButtonGroup grp = new ButtonGroup();
        grp.add(radioHomme);
        grp.add(radioFemme);
        
    	for (int i = 0; i < Sports.NOMBRE; i++) {
    	    casesACocherSports[i] = new JCheckBox(Sports.values()[i].toString());
    	    grandEst.add( casesACocherSports[i] );
    	}

        grandSud.add(butOK);
        grandSud.add(butAnnuler);
        butOK.setPreferredSize( butAnnuler.getPreferredSize() );
		
        this.pack();
    }
    
    public void setMembre( Membre membre ) {
    	txtNom.setText(membre.nom);
    	txtPrenom.setText(membre.prenom);
    	txtAdresse.setText(membre.adresse);
    	radioHomme.setSelected(membre.sexeMasculin);
    	radioFemme.setSelected( ! membre.sexeMasculin);
    	for (int i = 0; i < Sports.NOMBRE; i++) {
    		if ( membre.sportsChoisis.contains( Sports.values()[i] ) ) {
        		this.casesACocherSports[i].setSelected( true );
    		} else {
        		this.casesACocherSports[i].setSelected( false );
    		}
    	}
    }

} 