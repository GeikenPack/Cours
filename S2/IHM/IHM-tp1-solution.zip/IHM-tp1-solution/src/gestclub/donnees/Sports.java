package gestclub.donnees;

/**
 * Les sports possibles
 */
public enum Sports {
	
	Tennis, Squash, Natation, Athletisme, Randonnee, Foot, Basket, Volley, Petanque; 
	
	public static final int NOMBRE = values().length;

}
