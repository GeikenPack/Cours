import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Font;

@SuppressWarnings("serial")
public class PlusMoins extends JFrame implements ActionListener {

	private JTextField zoneTexte = new JTextField();

	static final int    VALEUR_INIT  = 10;
	static final String ACTION_PLUS  = "Plus";
	static final String ACTION_MOINS = "Moins";
	static final String ACTION_RAZ   = "Raz";


	public PlusMoins() {
		super();

		// Cr�ation des composants
		JPanel     panelBas  = new JPanel();
		JButton    butPlus   = new JButton("+");
		JButton    butMoins  = new JButton("-");
		JButton    butRaz    = new JButton("RAZ");
		Font       police    = new Font( "Arial", Font.BOLD, 18 );

		// Param�trage des composants
		this.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
		this.setTitle("Plus ou moins");

		butPlus.setBackground(  Color.GREEN );
		butMoins.setBackground( Color.RED   );
		butRaz.setBackground(   Color.BLUE  );

		this.zoneTexte.setText(""+VALEUR_INIT);
		this.zoneTexte.setEditable(false);
		this.zoneTexte.setHorizontalAlignment( JTextField.CENTER );
		this.zoneTexte.setBackground( Color.WHITE );

		this.zoneTexte.setFont(police);
		butPlus.setFont(police);
		butMoins.setFont(police);
		butRaz.setFont(police);

		// Assemblage des composants
		getContentPane().setLayout( new BorderLayout() );
		getContentPane().add( this.zoneTexte, BorderLayout.CENTER );
		getContentPane().add( panelBas,  BorderLayout.SOUTH );

		panelBas.setLayout( new GridLayout(1, 3) );
		panelBas.add(butPlus);
		panelBas.add(butRaz);
		panelBas.add(butMoins);

		// gestion des actions
		butPlus.setActionCommand( ACTION_PLUS);
		butMoins.setActionCommand(ACTION_MOINS);
		butRaz.setActionCommand(  ACTION_RAZ);
		butPlus.addActionListener(  this );
		butMoins.addActionListener( this );
		butRaz.addActionListener(   this );

		// Mise en page
		this.setSize(new Dimension(280, 120));

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		int valeur;
		try {
			valeur = Integer.parseInt( this.zoneTexte.getText() );
		} catch (NumberFormatException nfe) {
			valeur = VALEUR_INIT;
		}
		switch ( e.getActionCommand() ) {
		case ACTION_PLUS:
			valeur ++;
			break;
		case ACTION_MOINS:
			valeur --;
			break;
		case ACTION_RAZ:
			valeur = VALEUR_INIT;
			break;
		default:
			System.out.println("Action inconnue ???");
		}
		this.zoneTexte.setText(""+valeur);
	}


}
