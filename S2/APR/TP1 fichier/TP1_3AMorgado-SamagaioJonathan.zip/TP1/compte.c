//compte.c
#include "compte.h"
#include <stdio.h>
#include <stdlib.h>
char devise[KNBDEVISE][kLGCHAINE] = {"Euro", "Livre", "Dollar", "Yen"};
float tauxChange[KNBDEVISE] = {1.0, 1.2125 , 0.73791, 0.007083};


/* Affiche la liste des devises */
void affichageListeDevises()
{
  int i;
  for(i=0;i< KNBDEVISE;i++)
    printf("choix %d pour %s\n", i ,  devise[i]);
} //fin affichageListeDevises

Compte saisieCompte () 
{
  Compte unCompte;
  int i;
	int choix;
  printf("saisieCompte : solde du nouveaux compte :\n");
	scanf("%lf", &(unCompte.soldeCompte));//pas de controle

  printf("saisieCompte : Devise du nouveau compte :\n");
	affichageListeDevises();
  scanf("%d", &choix);
  //vérification que le choix est valide
	while (choix < 0 || choix >= KNBDEVISE)
  {
	  affichageListeDevises();
	  scanf("%d",&choix);
	}

	unCompte.indiceDevise=choix;

	return unCompte;
} // fin saisieCompte

void saisieTab (int pfNbC, Compte pfTabC[])
{
  //affichage de l'adresse  pfTabC
	printf("saisieTab : adresse de pfTabC %p\n", pfTabC);
  //Meme adresse que tabCompte de main
	//taille de pfTabC dans la pile
	printf("saisieTab : taille de pfTabC %ld\n", sizeof(pfTabC));
  //affichage de l'adresse de   pfTabC
	printf("saisieTab : adresse de pfNbC %p\n", &pfNbC);
	//taille de pfNbC dans la pile
	printf("saisieTab : taille de pfNbC %ld\n", sizeof(pfNbC));
  
  int i;
  for (i = 0; i < pfNbC; i++)
    pfTabC[i] = saisieCompte();
} // fin saisieTab

void afficheTab(int pfNbC, const Compte pfTabC[])
{
  //affichage de l'adresse  pfTabC
	printf("afficheTab : adresse de pfTabC %p\n", pfTabC);
  //Meme adresse que tabCompte de main
	//taille de pfTabC dans la pile
	printf("afficheTab : taille de pfTabC %ld\n", sizeof(pfTabC));
  //affichage de l'adresse de   pfNbC
	printf("afficheTab : adresse de pfNbC %p\n", &pfNbC);
	//taille de pfNbC dans la pile
	printf("afficheTab : taille de pfNbC %ld\n", sizeof(pfNbC));
  
  int i;
  for (i = 0; i < pfNbC; i++)
  {
    printf("afficheTab : %lf, %s \n", pfTabC[i].soldeCompte, devise[pfTabC[i].indiceDevise]);
  }
} //fin afficheTab

Compte changeEnEuros (Compte pfC)
{
  Compte unCompte;

  // décommenter le code suivant pour comprendre ce qui se passe  
  //affichage de l'adresse de  pfC
  printf("changeEnEuro : adresse de pfC %p\n", &pfC);
  //taille de pfC dans la pile
  printf("changeEnEuro : taille de pfC %ld\n", sizeof(pfC));
  //affichage de l'adresse de  unCompte
  printf("changeEnEuro : adresse de unCompte %p\n", &unCompte);
  //taille de unCompte dans la pile 16 octets
  printf("changeenEuro : taille de unCompte %ld\n", sizeof(unCompte));

  //traitement
  unCompte.indiceDevise = 0;
  unCompte.soldeCompte = pfC.soldeCompte*tauxChange[pfC.indiceDevise];
  return unCompte;
}//fin changeEnEuros