#include <stdio.h>
#include <stdlib.h>
#include "compte.h"



int main()
{
  Compte tabComptes [] =
    {{500.25, 1}, {129.3, 2},    {130.67, 3}, {12.8, 1},    {200.3, 2},    {700.67, 3}};
  int i;

  int nbComptes = 6;
  //Compte tabComptes[nbComptes];
  //saisieTab(nbComptes, tabComptes);
  //TODO afficher le tableau
  afficheTab(nbComptes, tabComptes);

  // pour comprendre
  //affichage de l'adresse  pfTabC pas m�me adresse
  printf("Main : adresse de tabc %p\n", tabComptes);
  //taille de pfTabC dans la pile 96 ici
  printf("Main : taille de tabc %ld\n", sizeof(tabComptes));

  Compte tabComtpesEuro[nbComptes];
  for(i = 0; i < nbComptes; i++)
  {
    //TODO transformer tous les comptes en euros
    tabComtpesEuro[i] = changeEnEuros(tabComptes[i]);
    // pour comprendre
    //affichage de l'adresse  pfTabC
    printf("Main : adresse du compte %p\n", &tabComtpesEuro[i]);
    //taille de pfTabC dans la pile
    printf("Main : taille du compte %ld\n", sizeof(tabComtpesEuro[i]));
  }
  //TODO afficher le tableau
  afficheTab(nbComptes, tabComtpesEuro);

  // system("pause");
   return 0;
}