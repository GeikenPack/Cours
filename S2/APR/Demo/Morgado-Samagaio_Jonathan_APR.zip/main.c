// tableau en entrée tableau en entrée sortie

#include <stdio.h>
void InitTabInt (int pftab[], int pfn); //pftab[] OUT, pfn IN
void affTabInt (const int pftab[], int pfn);//pftab[] IN, pfn IN


void affTabInt (const int pftab[], int pfn) { //pftab et pfn IN
     int i;
     printf("adresse du tableau %p entier %d\n", pftab, pfn);
     for (i=0; i<pfn; i++)
          printf("%d\n", pftab[i]);
            
}

void initTabInt (int pftab[], int pfn) {//pftab out pfn IN
     int i;
     printf("adresse du tableau %p entier %d\n", pftab, pfn);
     for (i=0; i<pfn; i++)
          pftab[i]=25+i;      
}

int main (void)
{
     int tabInt [5] ;
     int i=5 ;
     printf("adresse du tableau %p entier %d\n", tabInt, i);
     initTabInt(tabInt, 5);
     affTabInt (tabInt, i);
     return 0;
}

/*Pour cette démo

Vous devez observer la valeur de l'adresse du tableau dans les différents contexte (programme principal et sous programme).

Que constatez vous quand le tableau est en IN, IN/OUT ?
Le tableau est en IN seulement dans affTabInt qui s'occupe donc seulement de l'affichage du contenue du tableau et ne modifie rien grâce au const devant le nom du paramètre.
Il est en IN/OUT dans initTabInt ou le tableau recoit des valeurs et est donc modifié.

Qu'est ce qui est passé au sous-programme ?
L'adresse du tableau et sa taille sont passé en sous programme

Le sous-programme peut-il modifier le contenu du tableau ?
Le sous programme initTabInt peut modifier le contenu du tableau car le tableau est en IN/OUT
affTabInt ne peut pas modifier car le tableau est seulement fournis en IN avec le const.

Le tableau est il copié lors du passage de paramètre ?
Non. Seulement son adresse est copié.

Que concluez vous ?
Seul le tableau tabInt du main est modifié. Les tableaux présent dans les sous programmes sont aussi tabInt car seulement son adresse est pasé en paramètre.

*/