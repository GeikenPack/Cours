#include <stdio.h>
#include <stdlib.h>
#include "fonctions.h"

int main()
{
  //Declaration eds variables
  int val1, val2;
  Etudiant unEtu = {"Titi", 8.5, 'N'};

  //Saisie controler de val1
  printf("Saisissez une valeur entre 1 et 10 :");
  scanf("%d", &val1);
  viderStdin();
  while (val1 < 1 || val1 > 10)
  {
    printf("Saisie incorrecte. Saisissez une valeur entre 1 et 10 :");
    scanf("%d", &val1);
    viderStdin();
  }

  //Sauvegarde de val1 dans val2
  val2 = val1;

  //Appel de modif1Val
  val1 = modif1Val(val1);

  //Appel de afficheVal avec afficheVal
  afficheVal(val1);

  //Appel de modif2Val avec val2
  modif2Val(&val2);

  //Appel de afficheVal avec val2
  afficheVal(val2);

  //Appel de modifEtu avec unEtu
  modifEtu(&unEtu);

  //Appel de afficheEtu avec unEtu
  afficheEtu(&unEtu);
  return 0;
}