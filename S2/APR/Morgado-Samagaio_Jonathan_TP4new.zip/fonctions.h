//fonctions.h

#define LNOM (10)

//Type Etudiant
typedef struct
{
  char nom [LNOM];
  double moy;
  char codeSem;
} Etudiant;

/**
*Permet de vider le buffer associé à l'entrée standard
*/
void viderStdin(void);

/*
*Permet d'afficher la valeur de la variable donnée en entrée
*
*@param pfVal IN : Valeur fourni
*/
void afficheVal(int pfVal);

/*
*Permet de modifier la valeur du paramètre d'entrée et la renvoie
*
*@param pfVal IN : Valeur fourni
*/
int modif1Val(int pfVal);

/*
*Permet de modifier la valeur du paramètre d'entrée
*
*@param pfVal IN/OUT : Valeur fourni
*/
void modif2Val(int* pfVal);

/*
*Permet d'afficher les différents champs d'un Etudiant passé en entrée
*
*@param pfEtu IN : Etudiant a afficher
*/
void afficheEtu(const Etudiant *pfEtu);

/*
*Permet de saisir les champs d'un Etudiant fournis en entrée
*
*@param pfEtu IN/OUT : Etudiant a saisir
*/
void saisieEtu(Etudiant *pfEtu);

/*
*Permet de modifier le code semestre d'un Etudiant en entrée
*
*@param pfEtu IN/OUT : Etudiant a modifier
*/
void modifEtu(Etudiant *pfEtu);