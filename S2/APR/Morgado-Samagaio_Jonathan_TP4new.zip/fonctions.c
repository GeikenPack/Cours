#include <stdio.h>
#include <stdlib.h>
#include "fonctions.h"

void viderStdin()
{
  char ch;
  ch = getchar();
  while(ch != '\n'&&ch != EOF)
    ch = getchar();
}

/*NH : parfait !*/
void afficheVal(int pfVal)
{
  //Affiche la valeur fournis
  printf("Valeur fournis : %d\n", pfVal);
}

int modif1Val(int pfVal)
{
  //Renvoie le carré de la valeur fournis
  return pfVal*pfVal;
}

void modif2Val(int* pfVal)
{
  //Renvoie le carré de la valeur fournis
  *pfVal = *pfVal * *pfVal;
}

void afficheEtu(const Etudiant *pfEtu)
{
  //Affiche tous les champs de l'Etudiant
  printf("Affichage de l'etudiant :\n");
  printf("Nom : %s\nMoyenne du S1 : %lf\nCode du semestre : %c", pfEtu->nom, pfEtu->moy, pfEtu->codeSem);
}

void saisieEtu(Etudiant * pfEtu)
{
  //Saisie de l'Etudiant
  printf("Saisie de l'Etudiant :\n");
  printf("Saisie du nom : ");
  scanf("%s", pfEtu->nom);
  viderStdin();
  printf("Saisie de la moyenne : ");
  scanf("%lf", &pfEtu->moy);
  viderStdin();
  printf("Saisie du code du semestre : ");
  scanf("%c", &pfEtu->codeSem);
  viderStdin();
}

void modifEtu(Etudiant * pfEtu)
{
  //Modifie le code du semestre suivant la valeur de la moyenne
  if (pfEtu->moy >= 10)
  {
    pfEtu->codeSem = 'V';
  }
  else if (pfEtu->moy >= 8)
  {
    pfEtu->codeSem = 'A';
  }
  else
  {
    pfEtu->codeSem = 'R';
  }
}