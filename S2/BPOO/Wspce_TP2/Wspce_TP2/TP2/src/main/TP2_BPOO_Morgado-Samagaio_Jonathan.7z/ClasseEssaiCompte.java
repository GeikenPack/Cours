package main;

import tps.banque.Compte;
import tps.banque.exception.CompteException;

public class ClasseEssaiCompte {
	public static void main(String[] argv) {
		Compte cUn; //Cr�er un compte
		 
	}
}