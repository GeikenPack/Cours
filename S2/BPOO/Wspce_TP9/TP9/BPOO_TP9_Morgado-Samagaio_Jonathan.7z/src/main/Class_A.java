package main;

public class Class_A {

    public void afficher () {
            System.out.println("Afficher : Class A");
    }

    public void afficher_AUTRE () {
            System.out.println("Afficher_AUTRE : Class A");
    }
}
