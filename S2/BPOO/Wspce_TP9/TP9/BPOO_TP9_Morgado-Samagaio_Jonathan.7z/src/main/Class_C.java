package main;

public class Class_C  extends Class_B 
{
	public void afficher_AUTRE()
	{
		System.out.println("Afficher_AUTRE : Class C");
	}
}
