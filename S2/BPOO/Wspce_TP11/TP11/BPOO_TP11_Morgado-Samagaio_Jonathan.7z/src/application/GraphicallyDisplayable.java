package application;

public interface GraphicallyDisplayable 
{
	public void graphicallyDisplayObject();
}
