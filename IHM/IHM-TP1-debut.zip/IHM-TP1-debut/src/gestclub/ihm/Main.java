package gestclub.ihm;

public class Main {

	public static void main(String[] args) {
		System.out.println("Mon programme fonctionne !");
		System.out.println("J'utilise le JDK : "+System.getProperty("java.version"));

	}

}
