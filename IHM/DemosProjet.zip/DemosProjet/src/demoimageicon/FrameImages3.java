package demoimageicon;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

/**
 * Cet exemple est a comparer avec FrameImage2
 * 
 * @author Fabrice Pelleau
 *
 */
@SuppressWarnings("serial")
public class FrameImages3 extends JFrame implements ActionListener {
	
	public static final String ETAT_VIDE  = "vide";
	public static final String ETAT_NOIR  = "noir";
	public static final String ETAT_BLANC = "blanc";

	public final ImageIcon icoBlanc = new ImageIcon( getClass().getResource("/demoimages/images/blanc_64.png") );
	public final ImageIcon icoNoir  = new ImageIcon( getClass().getResource("/demoimages/images/noir_64.png") );
	public final ImageIcon icoVert  = new ImageIcon( getClass().getResource("/demoimages/images/vert_64.png") );

	public static void main(String[] args) {
		FrameImages3 frame = new FrameImages3();
		frame.setVisible(true);
	}

	public FrameImages3() {
		this.setTitle("D�mo Images");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.getRootPane().setBorder( BorderFactory.createEmptyBorder( 5, 5, 5, 5) );
		
		JLabel labelHaut = new JLabel("<html><center>Cliquez dans les cases...</center></html>");
		getContentPane().add(labelHaut, BorderLayout.NORTH);
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(new GridLayout(3, 6));
		
		
		Color     couleurBouton = new Color(63,153,45);
		Dimension tailleBouton  = new Dimension(64, 64);
		
		for (int i=0; i<18; i++) {
			JButton but = new JButton();
			but.setPreferredSize(tailleBouton);
			but.setBackground(couleurBouton);
			but.setActionCommand(ETAT_VIDE);
			but.addActionListener(this);
			panel.add(but);
		}
		
		this.pack();
		
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource() instanceof JButton) {
			JButton caseChoisie = (JButton)event.getSource();
			if (caseChoisie.getActionCommand()==ETAT_VIDE) {
				caseChoisie.setActionCommand(ETAT_BLANC);
				caseChoisie.setIcon(this.icoBlanc);
			} else if (caseChoisie.getActionCommand()==ETAT_BLANC) {
				caseChoisie.setActionCommand(ETAT_NOIR);
				caseChoisie.setIcon(this.icoNoir);
			} else {
				caseChoisie.setActionCommand(ETAT_VIDE);
				caseChoisie.setIcon(this.icoVert);
			}
		}
		
		
	}

}
