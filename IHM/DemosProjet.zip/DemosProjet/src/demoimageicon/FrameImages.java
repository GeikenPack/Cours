package demoimageicon;

import java.awt.BorderLayout;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.GridLayout;
import javax.swing.JButton;

/**
 * Exemple (pas tr�s beau) de 3 icones dans des boutons
 * @author Fabrice Pelleau
 *
 */
@SuppressWarnings("serial")
public class FrameImages extends JFrame {

	public static void main(String[] args) {
		FrameImages frame = new FrameImages();
		frame.setVisible(true);
	}

	public FrameImages() {
		this.setTitle("D�mo Images");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(480, 240);
		this.getRootPane().setBorder( BorderFactory.createEmptyBorder( 5, 5, 5, 5) );
		
		JLabel labelHaut = new JLabel("<html><center>Avec cette technique on n'aura pas de probl�me dans un jar</center></html>");
		getContentPane().add(labelHaut, BorderLayout.NORTH);
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(new GridLayout(1, 0, 0, 0));
		
		ImageIcon ico1 = new ImageIcon( getClass().getResource("/demoimages/images/pion_noir.png") );
		ImageIcon ico2 = new ImageIcon( getClass().getResource("/demoimages/images/pion_rouge.png") );
		ImageIcon ico3 = new ImageIcon( getClass().getResource("/demoimages/images/pion_vert.png") );
		
		JButton btn1 = new JButton(ico1);
		JButton btn2 = new JButton("Bouton2", ico2);
		JButton btn3 = new JButton(ico3);

		panel.add(btn1);
		panel.add(btn2);
		panel.add(btn3);
		
	}

}
