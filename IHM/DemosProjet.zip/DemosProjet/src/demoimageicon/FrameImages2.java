package demoimageicon;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

/**
 * Il n'y a pas d'image dans cet exemple... c'est pour le comparer avec FrameImage3 (qui lui a des images)
 * 
 * @author Fabrice Pelleau
 *
 */
@SuppressWarnings("serial")
public class FrameImages2 extends JFrame implements ActionListener {
	
	public static final String ETAT_VIDE  = "vide";
	public static final String ETAT_NOIR  = "noir";
	public static final String ETAT_BLANC = "blanc";

	public static void main(String[] args) {
		FrameImages2 frame = new FrameImages2();
		frame.setVisible(true);
	}

	public FrameImages2() {
		this.setTitle("D�mo Images");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.getRootPane().setBorder( BorderFactory.createEmptyBorder( 5, 5, 5, 5) );
		
		JLabel labelHaut = new JLabel("<html><center>Cliquez dans les cases...</center></html>");
		getContentPane().add(labelHaut, BorderLayout.NORTH);
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(new GridLayout(3, 6));
		
		
		Dimension tailleBouton  = new Dimension(64, 64);
		Font  f20  = new Font(Font.DIALOG_INPUT,  Font.BOLD, 20);
		
		for (int i=0; i<18; i++) {
			JButton but = new JButton();
			but.setPreferredSize(tailleBouton);
			but.setFont(f20);
			but.setActionCommand(ETAT_VIDE);
			but.addActionListener(this);
			panel.add(but);
		}
		
		this.pack();
		
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource() instanceof JButton) {
			JButton caseChoisie = (JButton)event.getSource();
			if (caseChoisie.getActionCommand()==ETAT_VIDE) {
				caseChoisie.setActionCommand(ETAT_BLANC);
				caseChoisie.setText("B");
			} else if (caseChoisie.getActionCommand()==ETAT_BLANC) {
				caseChoisie.setActionCommand(ETAT_NOIR);
				caseChoisie.setText("N");
			} else {
				caseChoisie.setActionCommand(ETAT_VIDE);
				caseChoisie.setText("-");
			}
		}
		
		
	}

}
