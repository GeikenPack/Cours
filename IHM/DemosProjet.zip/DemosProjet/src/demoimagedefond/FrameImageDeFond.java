package demoimagedefond;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

@SuppressWarnings("serial")
public class FrameImageDeFond extends JFrame {

	public FrameImageDeFond() {
		
		this.setSize(800,600);
		
		PanelAvecImage monPanel = new PanelAvecImage("/demoimages/images/plage1_800_600.jpg");
		monPanel.setPreferredSize(new Dimension(800, 600));
		monPanel.setLayout(new FlowLayout(FlowLayout.CENTER,600,80));

		Font    police = new Font( "Arial", Font.BOLD, 32 );

		JButton but1    = new JButton("Image 1");
		but1.setFont(police);
		but1.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				monPanel.setImage("/demoimages/images/plage2_800_600.jpg");
			}
		});
		JButton but2    = new JButton("Image 2");
		but2.setFont(police);
		but2.addActionListener( new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				monPanel.setImage("/demoimages/images/plage1_800_600.jpg");
			}
		});
		
		JLabel  txt    =  new JLabel("Cliquez sur un bouton pour changer l'image");
		txt.setForeground(Color.ORANGE);
		txt.setFont(police);

		monPanel.add( txt );
		monPanel.add(but1);
		monPanel.add(but2);
		
		this.add(monPanel, BorderLayout.CENTER);

	}
	public static void main(String[] args) {

		FrameImageDeFond fen = new FrameImageDeFond();
		fen.setVisible(true);

	}

}
