package demochrono;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.Timer;

@SuppressWarnings("serial")
public class FrameChrono extends JFrame {
	
	private JLabel infoChrono = new JLabel("Info Chrono");
	
	private long debut; // en ms
	
	private Timer timer = null;
	
	public FrameChrono() {
		super("demo chrono");
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		this.setSize(320,200);
		this.add(infoChrono, BorderLayout.CENTER);
		infoChrono.setHorizontalAlignment(JLabel.CENTER);
		
		this.debut = System.currentTimeMillis();
		
		this.timer = new Timer(1000, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				actualiseDuree();
			}
		});
		this.timer.start();
		
		JButton butRAZ = new JButton("RAZ");
		this.add(butRAZ, BorderLayout.SOUTH);
		butRAZ.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				FrameChrono.this.debut = System.currentTimeMillis();
				actualiseDuree();
			}
		});
		
		this.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				long fin = System.currentTimeMillis();
				double duree = (fin-debut)/1000;
				System.out.println("On a �t� ouvert "+duree+"s");
			}
		});
	}
	public void actualiseDuree() {
		long fin = System.currentTimeMillis();
		double duree = (fin-debut)/1000;
		this.infoChrono.setText(""+duree+"s");
	}

	public static void main(String[] args) {
		FrameChrono fenetre = new FrameChrono();
		fenetre.setVisible(true);
	}
}
