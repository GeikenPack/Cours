package demotimer;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JPanel;

import javax.swing.JLabel;
import java.awt.GridLayout;
import javax.swing.JButton;

@SuppressWarnings("serial")
public class FrameTimer extends JFrame {

	public static void main(String[] args) {
		FrameTimer frame = new FrameTimer();
		frame.setVisible(true);
	}

	public FrameTimer() {
		this.setTitle("D�mo HTML");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(480, 240);
		this.getRootPane().setBorder( BorderFactory.createEmptyBorder( 5, 5, 5, 5) );
		JLabel labelHaut = new JLabel("<html><font color=blue>Petite d�monstration de l'utilisation de la classe</font><br/><font size=+2 color=red>javax.swing.Timer</font></html>");
		getContentPane().add(labelHaut, BorderLayout.NORTH);
		
		JPanel panel = new JPanel();
		getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(new GridLayout(1, 0, 0, 0));
		
		JButton btn1 = new JButton("Vert 1s");
		JButton btn2 = new JButton("Cyan 2s");
		JButton btn3 = new JButton("Coucou en boucle");

		btn1.addActionListener( new EcouteTimerUnique(btn1, Color.GREEN, 1000) );
		btn2.addActionListener( new EcouteTimerUnique(btn2, Color.CYAN,  2000) );
		btn3.addActionListener( new EcouteTimerBoucle("Coucou toutes les 3 secondes", 3000) );
		
		panel.add(btn1);
		panel.add(btn2);
		panel.add(btn3);
		
	}

}
