package demotimer;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

/**
 * Cet �couteur va afficher un message en boucle toutes les X ms.
 * 
 * @author Fabrice Pelleau
 */
public class EcouteTimerBoucle implements ActionListener {
	private String message;
	private int    duree;
	
	public EcouteTimerBoucle(String message, int duree) {
		this.message = message;
		this.duree   = duree;
	}

	public void actionPerformed(ActionEvent ev) {

//		Timer timer2 = new Timer( duree, (e)->System.out.println( message ) );
		Timer timer2 = new Timer( duree, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.out.println( message );
			}
		});
		//timer2.setRepeats(false); // si on pr�cisait �a il ne s'executerait qu'une seule fois
		timer2.start();
		
	}
	

}
