package demotimer;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.Timer;

/**
 * Cet �couteur va changer la couleur d'un bouton pendant un certain temps puis lui redonner sa couleur par d�faut.
 * 
 * La couleur est chang�e par 2 m�thodes :
 *   - donnerCouleurAction()
 *   - donnerCouleurDepart()
 *   
 * Il faut donc lancer donnerCouleurAction() imm�diatement puis donnerCouleurDepart() un peu plus tard
 * 
 * @author Fabrice Pelleau
 */
public class EcouteTimerUnique implements ActionListener {
	private JButton bouton;
	private  int    duree;
	private Color   couleurAction;
	private Color   couleurDeDepart;
	
	public EcouteTimerUnique(JButton bouton, Color couleur, int duree) {
		this.bouton  = bouton;
		this.duree   = duree;
		this.couleurAction   = couleur;
		this.couleurDeDepart = bouton.getBackground();
	}
	
	private void donnerCouleurAction() {
		this.bouton.setBackground( this.couleurAction );
	}
	
	private void donnerCouleurDeDepart() {
		this.bouton.setBackground( this.couleurDeDepart );
	}

	public void actionPerformed(ActionEvent ev) {

		// imm�diatement
		donnerCouleurAction();
		
		// dans "duree" ms
		Timer timer = new Timer(duree, new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				donnerCouleurDeDepart();
			}
		} );
		timer.setRepeats(false);
		timer.start();
		
	}
	

}
