package demohtml;

import java.awt.BorderLayout;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

@SuppressWarnings("serial")
public class FrameHTML extends JFrame {

	public static void main(String[] args) {
		FrameHTML frame = new FrameHTML();
		frame.setVisible(true);
	}

	public FrameHTML() {
		this.setTitle("D�mo HTML");
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(480, 398);
		this.getRootPane().setBorder( BorderFactory.createEmptyBorder( 5, 5, 5, 5) );
		JLabel labelCentral = new JLabel(
				"<html>"+
				"<h1>En utilisant HTML dans un JLabel,<br/> vous pouvez :</h1>"+
				"<ul>"+
				"<li>cr�er un JLabel sur plusieurs lignes ;</li>"+
				"<li><u>mettre en forme</u> <i>du texte</i></li>"+
				"<li>bref, faire ce que vous savez faire en<br/><big>HTML</big></li>"+
				"</ul>"+
				"</html>"
				);
		JLabel  labelHaut  = new JLabel("<html>un label<br/>sur 3 lignes<br/>en HTML</html>");
		JButton bouton = new JButton("<html>bouton<br/><u>HTML</u></html>");
		bouton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
				JOptionPane.showMessageDialog(null, "<html><h1>Un message</h1><h2>en HTML</h2></html>", "exemple", JOptionPane.INFORMATION_MESSAGE);
			}
		});

		this.getContentPane().add(labelCentral, BorderLayout.CENTER);
		this.getContentPane().add(labelHaut, BorderLayout.NORTH);
		this.getContentPane().add(bouton, BorderLayout.SOUTH);
	}

}
