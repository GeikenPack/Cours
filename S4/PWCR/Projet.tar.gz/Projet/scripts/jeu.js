let nbJoueurs = 2
let blackBot = new BlackBot(nbJoueurs)

const defCroupierHtml = '<h2 class="nomCroupier">Croupier</h2>' +
                        '<div class="carteBanque cartes"></div>' +
                        '<div class="score scoreCroupier"></div>'


$('document').ready(function() {
    const $zoneCroupier = $('.croupier')
    const $zoneJoueurs = $('#joueurs')
    //Ajout de la zone du croupier
    $zoneCroupier.append(defCroupierHtml)

    ajoutJoueurs()
    actualiserJoueurs()

    $('.tirage').attr('disabled','disabled').click(function() {
        blackBot.distribuer()
        actualiserJoueurs()
        passageJeu()
    })

    $('.recommencer').attr('disabled','disabled').click(function() {
        blackBot.relancerPartie()
        actualiserJoueurs()
        passageMise()
        $('.message').html("")
    })

    function ajoutJoueurs() {
        $zoneJoueurs.html('')
        //Ajout des zones des joueurs
        for (let i = 0; i < nbJoueurs; i++){
            $zoneJoueurs.append('<div class="joueur">' +
                                '<h2 class="nomJoueur">Joueur '+i+'</h2>' +
                                '<div class="cartes'+i+' cartes"></div>' +
                                '<div class="score scoreJoueur'+i+'"></div>' +
                                '<div class="mise miseJoueur'+i+'">'+blackBot.miseJoueurs[i]+'</div>' +
                                '<div class="boutonsJoueurs">' +
                                    '<button class="miser'+i+'">Miser</button>' +
                                    '<button class="tirer'+i+'">Tirer</button>' +
                                    '<button class="stop'+i+'">Stop</button>' +
                                '</div>' +
                                '</div>')

            $('.miser'+i).click(function() {
                blackBot.miser(i, 10)
                $('.miseJoueur'+i).text(blackBot.miseJoueurs[i])
                actualiserJoueurs()
                $('.tirage').removeAttr('disabled')
            })

            $('.tirer'+i).attr('disabled', 'disabled').click(function() {
                blackBot.tirer(i)
                actualiserJoueurs()
                checkFinPartie()
            })

            $('.stop'+i).attr('disabled', 'disabled').click(function() {
                blackBot.terminer(i)
                actualiserJoueurs()
                checkFinPartie()
            })
        }
        $zoneJoueurs.append('<div class="butGestJoueurs"></div>')
        if (nbJoueurs <= 6) {
            $('.butGestJoueurs').append('<button class="addJoueur">+</button>')
        }
        if (nbJoueurs > 0) {
            $('.butGestJoueurs').append('<button class="removeJoueur">-</button>')
        }

        $('.addJoueur').click(function(){
            nbJoueurs++
            blackBot = new BlackBot(nbJoueurs)
            ajoutJoueurs()
            actualiserJoueurs()
        })

        $('.removeJoueur').click(function(){
            nbJoueurs--
            blackBot = new BlackBot(nbJoueurs)
            ajoutJoueurs()
            actualiserJoueurs()
        })
    }

    function actualiserJoueurs() {
        for (let i = 0; i < nbJoueurs; i++) {
            actualiserCartesJoueur(i)
            $('.miseJoueur'+i).html("Mise : " + blackBot.miseJoueurs[i])
            $('.scoreJoueur'+i).html("Score : " + blackBot.mainJoueurs[i].getScore())
            if (blackBot.etat === EtatBlackBot.GAIN || blackBot.finJoueurs[i] === true) {
                $('.miser'+i).attr('disabled', 'disabled')
                $('.tirer'+i).attr('disabled', 'disabled')
                $('.stop'+i).attr('disabled', 'disabled')
            }
        }
        actualiserCartesBanque()
        $('.scoreCroupier').text("Score : " + blackBot.mainBanque.getScore())
        if (blackBot.etat === EtatBlackBot.GAIN) {
            $('.recommencer').removeAttr('disabled')
        } else {
            $('.recommencer').attr('disabled', 'disabled')
        }
    }

    function passageJeu(){
        for (let i = 0; i < nbJoueurs; i++) {
            if (blackBot.miseJoueurs[i] > 0){
                $('.miser'+i).attr('disabled', 'disabled')
                $('.tirer'+i).attr('disabled',false)
                $('.stop'+i).removeAttr('disabled')
            } else {
                $('.miser'+i).attr('disabled', 'disabled')
                $('.tirer'+i).attr('disabled', 'disabled')
                $('.stop'+i).attr('disabled', 'disabled')
            }
        }
        $('.tirage').attr('disabled', 'disabled')
        $('.addJoueur').attr('disabled', 'disabled')
        $('.removeJoueur').attr('disabled', 'disabled')
    }

    function passageMise() {
        for (let i = 0; i < nbJoueurs; i++) {
            $('.miser'+i).removeAttr('disabled')
            $('.tirer'+i).attr('disabled', 'disabled')
            $('.stop'+i).attr('disabled', 'disabled')
        }
        $('.addJoueur').removeAttr('disabled')
        $('.removeJoueur').removeAttr('disabled')
    }

    function checkFinPartie() {
        for (let i = 0; i < blackBot.finJoueurs.length; i++) {
            if (blackBot.finJoueurs[i] === false) {return}
        }
        let meilleurScore = 0
        let indMeilleurScore = -1
        for (let i = 0; i < blackBot.mainJoueurs.length; i++) {
            if (blackBot.mainBanque.getScore() < 21){
                if(blackBot.mainJoueurs[i].getScore() > blackBot.mainBanque.getScore() &&
                blackBot.mainJoueurs[i].getScore() <= 21) {
                    if (meilleurScore < blackBot.mainJoueurs[i].getScore()) {
                        meilleurScore = blackBot.mainJoueurs[i].getScore();
                        indMeilleurScore = i
                    }
                }
            } else {

            }
        }
        console.log(meilleurScore);
        if (meilleurScore === 0) {
            //Banquier gagne
            afficherMessage("Le banquier à gagné !")
        } else {
            //Joueur gagne
            afficherMessage("Le joueur " + indMeilleurScore + " à gagné !")
        }
    }

    function afficherMessage(message) {
        $('.message').html(message)
    }

    function actualiserCartesJoueur(indJoueur){
        $('.cartes'+indJoueur).empty()
        for (let i = 0; i < blackBot.mainJoueurs[indJoueur].getNbCartes(); i++){
            let carteAct = blackBot.mainJoueurs[indJoueur].cartes[i]
            $(".cartes"+indJoueur).append('<img src="resources/Cartes/' + NomCarte[carteAct.hauteur]+'_'+CouleurCarte[carteAct.couleur]+'.png" width="100" height="180"></img>')
        }
    }

    function actualiserCartesBanque(){
        $(".carteBanque").empty()
        for (let i = 0; i < blackBot.mainBanque.getNbCartes(); i++){
            let carteAct = blackBot.mainBanque.cartes[i]
            $(".carteBanque").append('<img src="resources/Cartes/' + NomCarte[carteAct.hauteur]+'_'+CouleurCarte[carteAct.couleur]+'.png" width="100" height="180"></img>')
        }
    }
})