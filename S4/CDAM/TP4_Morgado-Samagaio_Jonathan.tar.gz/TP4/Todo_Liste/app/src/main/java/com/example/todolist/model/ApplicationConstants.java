package com.example.todolist.model;

public class ApplicationConstants {
    public static final int SHOW_TODO = 100;
    public static final int CREATE_TODO = 200;
    public static final int MODIFY_TODO = 300;
}
